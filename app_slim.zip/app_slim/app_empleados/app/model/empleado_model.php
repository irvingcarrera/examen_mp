<?php
namespace App\Model;

use App\Lib\Database;
use App\Lib\Response;

class EmpleadoModel
{
    private $empleados;
    // private $table = 'empleado';
    private $response;
    
    public function __CONSTRUCT()
    {
        $this->empleados = Database::StartUp();
        $this->response = new Response();
    }
    
    public function GetResumenAll()
    {
		try
		{
			$result = array();

			// $stm = $this->db->prepare("SELECT * FROM $this->table");
			// $stm->execute();
            
			foreach($this->empleados as $empleadoActual){
			   $resumenEmpleadoActual=array(
				   "id"=>$empleadoActual["id"],
				   "name"=>$empleadoActual["name"],
				   "email"=>$empleadoActual["email"],
				   "position"=>$empleadoActual["position"],
				   "salary"=>$empleadoActual["salary"]
			   );
			   $result[]=$resumenEmpleadoActual;
			}	
			
			$this->response->setResponse(true);
            $this->response->result = $result;
            
            return $this->response;
		}
		catch(Exception $e)
		{
			$this->response->setResponse(false, $e->getMessage());
            return $this->response;
		}
    }
    
    public function GetDetalleById($id)
    {
		try
		{
			$result = array();
			
			foreach($this->empleados as $empleadoActual){
			    if($id == $empleadoActual['id']){
				   $result=$empleadoActual;				
				}
			}			

			$this->response->setResponse(true);
            $this->response->result = $result;
            
            return $this->response;
		}
		catch(Exception $e)
		{
			$this->response->setResponse(false, $e->getMessage());
            return $this->response;
		}  
    } 
	
    public function GetResumenByEmail($email)
    {
		try
		{
			$result = array();
			
			foreach($this->empleados as $empleadoActual){
			
			    $pos = strpos($empleadoActual['email'], $email);
				if ($pos === false) {
				    continue;
					//// email es distinto al que se requiere, no se hace nada pasar al siguiente
				}
				
			   $resumenEmpleadoActual=array(
				   "id"=>$empleadoActual["id"],
				   "name"=>$empleadoActual["name"],
				   "email"=>$empleadoActual["email"],
				   "position"=>$empleadoActual["position"],
				   "salary"=>$empleadoActual["salary"]
			   );				
			   
			    $result[]=$resumenEmpleadoActual;
			}			

			$this->response->setResponse(true);
            $this->response->result = $result;
            
            return $this->response;
		}
		catch(Exception $e)
		{
			$this->response->setResponse(false, $e->getMessage());
            return $this->response;
		}  
    }
	
	public function GetResumenBySalary($salarioMinimo,$salarioMaximo)
    {
		try
		{
			$result = array();
			
			foreach($this->empleados as $empleadoActual){
			
			    $pos = strpos($empleadoActual['email'], $email);
				if ($pos === false) {
				    continue;
					//// email es distinto al que se requiere, no se hace nada pasar al siguiente
				}
				
			   $resumenEmpleadoActual=array(
				   "id"=>$empleadoActual["id"],
				   "name"=>$empleadoActual["name"],
				   "email"=>$empleadoActual["email"],
				   "position"=>$empleadoActual["position"],
				   "salary"=>$empleadoActual["salary"]
			   );				
			   
			    $result[]=$resumenEmpleadoActual;
			}			

			$this->response->setResponse(true);
            $this->response->result = $result;
            
            return $this->response;
		}
		catch(Exception $e)
		{
			$this->response->setResponse(false, $e->getMessage());
            return $this->response;
		}  
    }
	
}