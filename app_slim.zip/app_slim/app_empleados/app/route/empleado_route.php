<?php

use App\Model\EmpleadoModel;

$app->group('/empleado/', function () {
    
    $this->get('', function ($req, $res, $args) {
		
	    $args['email']='';
	    $datosform=$req->getParams();		
		
		$em = new EmpleadoModel();
		if(isset($datosform['email']) && (!empty($datosform['email']))){
			$args['email']=$datosform['email'];
			$args['listaEmpleados']=$em->GetResumenByEmail($datosform['email'])->result;	
		}else{
		    $args['listaEmpleados']=$em->GetResumenAll()->result;
		}
		// $args['listaEmpleados']=$em->GetResumenAll()->result;
		return $this->renderer->render($res, 'listaInicialempleados.phtml', $args);
		
    });
	
	$this->get('detalle/{id}', function ($req, $res, $args) {
		$em = new EmpleadoModel();
		$args['detalleEmpleado']=$em->GetDetalleById($args['id'])->result;
		return $this->renderer->render($res, 'detalleEmpleado.phtml', $args);
    });
	
    $this->get('name/{name}', function ($req, $res, $args) {
        //return $res->render()->write('Hello Empleados');
	    return $this->renderer->render($res, 'index.phtml', $args);
    });
	
	$this->get('getAll', function ($req, $res, $args) {
        $em = new EmpleadoModel();
        
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                $em->GetResumenAll()
            )
        );
    });	
	
	$this->get('getById/{id}', function ($req, $res, $args) {
        $em = new EmpleadoModel();
        
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                $em->GetDetalleById($args['id'])
            )
        );
    });	
	
	
	$this->get('getByEmail/{email}', function ($req, $res, $args) {
        $em = new EmpleadoModel();
        
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                $em->GetResumenByEmail($args['email'])
            )
        );
    });
    
});